# Mira Camera (v0.2.0)

Changelog
- 0.2.0: Settings > Camera info (lists the cameras/lenses Android exposes; used to design lens switching).
- 0.1.0: first version. GitHub Actions build succeeded (screenshot, run #2); not yet tested on a device.


Android camera + filter + photo-editor app. Kotlin, Jetpack Compose, CameraX. Min Android 10 (API 29).

## Build the APK

### A. Phone only (GitHub Actions, free account)
1. Create a GitHub repository (default branch `main`).
2. Upload `MiraCamera.zip` to the repository (Add file > Upload files). Do not unzip it.
3. Add file > Create new file, name it `.github/workflows/build.yml`, paste the contents of `build.yml`, commit.
4. Open the Actions tab. When "Build APK" finishes (about 5-10 min) open the repository's Releases page and tap `app-debug.apk`.
5. If the build fails, open the failed run, copy the red error lines, and send them to Claude to fix.

### B. Android Studio (computer)
1. Install Android Studio (free). Unzip `MiraCamera.zip`. File > Open > select the folder.
2. Let Gradle sync (needs internet the first time). Build > Build APK(s).
3. APK: `app/build/outputs/apk/debug/app-debug.apk`.

### Install on the phone
Open the APK, allow "Install unknown apps" for your browser/files app when asked, then Install.
Debug APKs are for testing. A signed release APK needs your own keystore (not created here).

## Status (nothing below has been run on a device yet)
Implemented in source, not yet compiled or tested: camera (front/back, flash, zoom, tap-to-focus, exposure, timer), 24 original filters in 12 styles with intensity + hold-to-compare + reset, auto-enhance, rotate, crop, save to in-app album AND phone gallery (Pictures/MiraCamera), album grid, full-screen preview with share/delete(confirm)/edit, settings (language TH/EN, quality, gallery toggle, default intensity, cache clear, privacy, AI info).

Not implemented (UI says "Setup required", nothing is faked): AI style transfer, background removal, object removal, portrait editing, text-prompt editing. These need an on-device model or an online provider + backend (no API keys inside the app).
Known limits: filters apply after capture (no live filtered preview); text labels instead of icons on most camera controls.
