package com.mira.camera

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import androidx.annotation.StringRes
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

enum class FilterStyle(@StringRes val label: Int) {
    NATURAL(R.string.style_natural),
    ANALOG(R.string.style_analog),
    JAPANESE(R.string.style_japanese),
    KOREAN(R.string.style_korean),
    VINTAGE(R.string.style_vintage),
    CINEMATIC(R.string.style_cinematic),
    NIGHT(R.string.style_night),
    FLASH(R.string.style_flash),
    WARM(R.string.style_warm),
    COOL(R.string.style_cool),
    MONO(R.string.style_mono),
    PORTRAIT(R.string.style_portrait),
    SOFT(R.string.style_soft),
    RETRO(R.string.style_retro)
}

class FilterPreset(
    val id: String,
    val style: FilterStyle,
    val name: String,
    val bright: Float = 0f,
    val contrast: Float = 1f,
    val sat: Float = 1f,
    val warmth: Float = 0f,
    val tint: Float = 0f,
    val fade: Float = 0f,
    val vignette: Float = 0f,
    val grain: Float = 0f
)

object FilterEngine {

    val presets: List<FilterPreset> = listOf(
        FilterPreset("an1", FilterStyle.ANALOG, "Amber Reel", contrast = 1.1f, sat = 0.9f, warmth = 0.35f, fade = 0.25f, vignette = 0.25f, grain = 0.35f),
        FilterPreset("an2", FilterStyle.ANALOG, "Dusty Roll", contrast = 1.05f, sat = 0.8f, warmth = 0.15f, tint = 0.1f, fade = 0.35f, vignette = 0.3f, grain = 0.45f),
        FilterPreset("jp1", FilterStyle.JAPANESE, "Sakura Air", bright = 0.06f, contrast = 0.92f, sat = 0.85f, warmth = -0.05f, tint = -0.05f, fade = 0.15f),
        FilterPreset("jp2", FilterStyle.JAPANESE, "Quiet Morning", bright = 0.08f, contrast = 0.9f, sat = 0.75f, warmth = -0.1f, fade = 0.2f),
        FilterPreset("kr1", FilterStyle.KOREAN, "Milk Tea", bright = 0.08f, contrast = 0.92f, sat = 0.9f, warmth = 0.12f, tint = -0.05f, fade = 0.1f),
        FilterPreset("kr2", FilterStyle.KOREAN, "Peach Glow", bright = 0.1f, contrast = 0.9f, sat = 1.0f, warmth = 0.2f, tint = -0.1f, fade = 0.08f),
        FilterPreset("vi1", FilterStyle.VINTAGE, "Old Postcard", contrast = 0.95f, sat = 0.7f, warmth = 0.3f, fade = 0.4f, vignette = 0.35f, grain = 0.2f),
        FilterPreset("vi2", FilterStyle.VINTAGE, "Faded Letter", sat = 0.6f, warmth = 0.25f, fade = 0.5f, vignette = 0.3f),
        FilterPreset("ci1", FilterStyle.CINEMATIC, "Teal Hour", contrast = 1.2f, sat = 1.05f, warmth = -0.2f, vignette = 0.35f),
        FilterPreset("ci2", FilterStyle.CINEMATIC, "Golden Frame", contrast = 1.2f, sat = 1.1f, warmth = 0.25f, vignette = 0.4f),
        FilterPreset("nf1", FilterStyle.FLASH, "Flash Glow", bright = 0.08f, contrast = 1.25f, sat = 1.1f, warmth = 0.1f, vignette = 0.45f),
        FilterPreset("nf4", FilterStyle.FLASH, "Direct Pop", bright = 0.1f, contrast = 1.2f, sat = 1.05f, warmth = -0.05f, vignette = 0.3f),
        FilterPreset("nf2", FilterStyle.NIGHT, "After Dark", bright = 0.03f, contrast = 1.3f, sat = 0.95f, warmth = -0.15f, vignette = 0.5f, grain = 0.2f),
        FilterPreset("nf3", FilterStyle.NIGHT, "Blue Hour", bright = 0.02f, contrast = 1.2f, sat = 1.0f, warmth = -0.3f, vignette = 0.4f, grain = 0.15f),
        FilterPreset("pt1", FilterStyle.PORTRAIT, "Gentle Tone", bright = 0.05f, contrast = 0.95f, sat = 0.95f, warmth = 0.12f, fade = 0.05f),
        FilterPreset("pt2", FilterStyle.PORTRAIT, "Studio Glow", bright = 0.06f, contrast = 1.05f, warmth = 0.08f, vignette = 0.2f),
        FilterPreset("na1", FilterStyle.NATURAL, "True Tone", contrast = 1.05f, sat = 1.05f),
        FilterPreset("na2", FilterStyle.NATURAL, "Clear Day", bright = 0.03f, contrast = 1.08f, sat = 1.1f, warmth = -0.03f),
        FilterPreset("bw1", FilterStyle.MONO, "Silver", contrast = 1.1f, sat = 0f),
        FilterPreset("bw2", FilterStyle.MONO, "Noir Grain", contrast = 1.3f, sat = 0f, vignette = 0.35f, grain = 0.45f),
        FilterPreset("wm1", FilterStyle.WARM, "Honey", sat = 1.05f, warmth = 0.4f),
        FilterPreset("wm2", FilterStyle.WARM, "Sunset Amber", contrast = 1.05f, sat = 1.1f, warmth = 0.6f),
        FilterPreset("cl1", FilterStyle.COOL, "Ice Blue", warmth = -0.4f),
        FilterPreset("cl2", FilterStyle.COOL, "Glacier", contrast = 1.05f, sat = 0.95f, warmth = -0.6f),
        FilterPreset("sf1", FilterStyle.SOFT, "Cloud", bright = 0.06f, contrast = 0.85f, sat = 0.95f, fade = 0.2f),
        FilterPreset("sf2", FilterStyle.SOFT, "Haze", bright = 0.05f, contrast = 0.8f, sat = 0.9f, warmth = 0.05f, fade = 0.3f),
        FilterPreset("rt1", FilterStyle.RETRO, "Arcade Pop", contrast = 1.15f, sat = 1.3f, warmth = 0.1f, tint = -0.1f),
        FilterPreset("rt2", FilterStyle.RETRO, "Cassette", contrast = 1.1f, sat = 1.2f, warmth = 0.2f, fade = 0.2f, vignette = 0.25f, grain = 0.25f)
    )

    private val noise: Bitmap by lazy {
        val s = 256
        val rnd = java.util.Random(42)
        val px = IntArray(s * s) {
            val v = (128 + rnd.nextGaussian() * 38).toInt().coerceIn(0, 255)
            Color.argb(255, v, v, v)
        }
        Bitmap.createBitmap(px, s, s, Bitmap.Config.ARGB_8888)
    }

    private fun matrix(p: FilterPreset): ColorMatrix {
        val m = ColorMatrix()
        m.setSaturation(p.sat)
        val s = p.contrast * (1f - p.fade * 0.15f)
        val t = 128f * (1f - p.contrast) + p.bright * 255f + p.fade * 40f
        val rOff = p.warmth * 22f
        val gOff = p.tint * 14f
        val bOff = -p.warmth * 22f
        val lin = ColorMatrix(
            floatArrayOf(
                s, 0f, 0f, 0f, t + rOff,
                0f, s, 0f, 0f, t + gOff,
                0f, 0f, s, 0f, t + bOff,
                0f, 0f, 0f, 1f, 0f
            )
        )
        m.postConcat(lin)
        return m
    }

    /** Returns a new bitmap: original blended with the filtered look at the given intensity (0..1). */
    fun apply(src: Bitmap, p: FilterPreset, intensity: Float): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawBitmap(src, 0f, 0f, null)
        val k = intensity.coerceIn(0f, 1f)
        if (k <= 0f) return out

        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(matrix(p))
        paint.alpha = (k * 255).toInt()
        c.drawBitmap(src, 0f, 0f, paint)

        if (p.vignette > 0f) {
            val a = (p.vignette * k * 230).toInt().coerceIn(0, 255)
            val vp = Paint()
            vp.shader = RadialGradient(
                w / 2f, h / 2f, hypot(w / 2f, h / 2f),
                intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(a, 0, 0, 0)),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), vp)
        }

        if (p.grain > 0f) {
            val sh = BitmapShader(noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
            val scale = (max(w, h) / 1280f).coerceAtLeast(0.5f)
            val lm = Matrix()
            lm.setScale(scale, scale)
            sh.setLocalMatrix(lm)
            val gp = Paint()
            gp.shader = sh
            gp.xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
            gp.alpha = (p.grain * k * 255).toInt().coerceIn(0, 255)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), gp)
        }
        return out
    }
}

/** On-device "auto enhance": levels stretch, gentle white-balance, saturation lift, light sharpening. */
object Enhancer {

    fun autoEnhance(src: Bitmap): Bitmap {
        val sc = min(1f, 200f / max(src.width, src.height))
        val sw = max(1, (src.width * sc).toInt())
        val sh = max(1, (src.height * sc).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val n = sw * sh
        val px = IntArray(n)
        small.getPixels(px, 0, sw, 0, 0, sw, sh)

        val hist = IntArray(256)
        var sr = 0L
        var sg = 0L
        var sb = 0L
        for (p in px) {
            val r = (p shr 16) and 255
            val g = (p shr 8) and 255
            val b = p and 255
            sr += r
            sg += g
            sb += b
            hist[(r * 299 + g * 587 + b * 114) / 1000]++
        }

        val cut = n * 0.01f
        var acc = 0
        var lo = 0
        while (lo < 255 && acc + hist[lo] < cut) {
            acc += hist[lo]
            lo++
        }
        acc = 0
        var hi = 255
        while (hi > 0 && acc + hist[hi] < cut) {
            acc += hist[hi]
            hi--
        }
        if (hi - lo < 20) hi = min(255, lo + 20)

        val scale = (255f / max(1, hi - lo)).coerceIn(1f, 1.5f)
        val mr = sr.toFloat() / n
        val mg = sg.toFloat() / n
        val mb = sb.toFloat() / n
        val ml = (mr + mg + mb) / 3f
        val gr = (ml / max(1f, mr)).coerceIn(0.9f, 1.1f)
        val gg = (ml / max(1f, mg)).coerceIn(0.9f, 1.1f)
        val gb = (ml / max(1f, mb)).coerceIn(0.9f, 1.1f)
        val off = ((118f - (ml - lo) * scale) * 0.5f).coerceIn(-25f, 25f)

        val cm = ColorMatrix(
            floatArrayOf(
                scale * gr, 0f, 0f, 0f, -lo * scale * gr + off,
                0f, scale * gg, 0f, 0f, -lo * scale * gg + off,
                0f, 0f, scale * gb, 0f, -lo * scale * gb + off,
                0f, 0f, 0f, 1f, 0f
            )
        )
        val sat = ColorMatrix()
        sat.setSaturation(1.08f)
        cm.postConcat(sat)

        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(cm)
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return sharpen(out, 0.35f)
    }

    /** Laplacian sharpen, processed in horizontal bands to keep memory low on large photos. */
    fun sharpen(src: Bitmap, amount: Float): Bitmap {
        val w = src.width
        val h = src.height
        val dst = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val band = 128
        var y0 = 0
        while (y0 < h) {
            val y1 = min(h, y0 + band)
            val top = max(0, y0 - 1)
            val bot = min(h, y1 + 1)
            val rows = bot - top
            val inPx = IntArray(w * rows)
            src.getPixels(inPx, 0, w, 0, top, w, rows)
            val outPx = IntArray(w * (y1 - y0))
            for (y in y0 until y1) {
                val yy = y - top
                val up = max(yy - 1, 0)
                val dn = min(yy + 1, rows - 1)
                for (x in 0 until w) {
                    val xl = if (x > 0) x - 1 else x
                    val xr = if (x < w - 1) x + 1 else x
                    val pc = inPx[yy * w + x]
                    val pu = inPx[up * w + x]
                    val pd = inPx[dn * w + x]
                    val pl = inPx[yy * w + xl]
                    val pr = inPx[yy * w + xr]
                    var res = 0xFF shl 24
                    var sh = 16
                    while (sh >= 0) {
                        val cc = (pc shr sh) and 0xFF
                        val v = cc + amount * (4 * cc -
                            ((pu shr sh) and 0xFF) - ((pd shr sh) and 0xFF) -
                            ((pl shr sh) and 0xFF) - ((pr shr sh) and 0xFF))
                        val iv = if (v < 0f) 0 else if (v > 255f) 255 else v.toInt()
                        res = res or (iv shl sh)
                        sh -= 8
                    }
                    outPx[(y - y0) * w + x] = res
                }
            }
            dst.setPixels(outPx, 0, w, 0, y0, w, y1 - y0)
            y0 = y1
        }
        return dst
    }
}

enum class CropAspect(val label: String, val ratio: Float?) {
    ORIGINAL("", null),
    SQUARE("1:1", 1f),
    R43("4:3", 4f / 3f),
    R169("16:9", 16f / 9f)
}

data class EditState(
    val preset: FilterPreset? = null,
    val intensity: Float = 0.8f,
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val flipV: Boolean = false,
    val crop: CropAspect = CropAspect.ORIGINAL,
    val enhance: Boolean = false,
    val frame: FrameStyle = FrameStyle.NONE,
    val watermark: Boolean = false,
    /** 0 bottom-left, 1 bottom-centre, 2 bottom-right, 3 top-left, 4 top-right */
    val wmPos: Int = 2,
    val wmSize: Float = 0.04f,
    val brightness: Float = 0f,
    val contrast: Float = 1f,
    val saturation: Float = 1f,
    val temperature: Float = 0f,
    val sharpness: Float = 0f
)

/** Manual tone adjustments (brightness, contrast, saturation, colour temperature) in one colour-matrix pass. */
object Adjuster {
    fun isNeutral(st: EditState): Boolean =
        abs(st.brightness) < 0.005f && abs(st.contrast - 1f) < 0.005f &&
            abs(st.saturation - 1f) < 0.005f && abs(st.temperature) < 0.005f

    fun apply(src: Bitmap, st: EditState): Bitmap {
        val m = ColorMatrix()
        m.setSaturation(st.saturation)
        val c = st.contrast
        val t = 128f * (1f - c) + st.brightness * 64f
        val lin = ColorMatrix(
            floatArrayOf(
                c, 0f, 0f, 0f, t + st.temperature * 25f,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t - st.temperature * 25f,
                0f, 0f, 0f, 1f, 0f
            )
        )
        m.postConcat(lin)
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val paint = Paint()
        paint.colorFilter = ColorMatrixColorFilter(m)
        Canvas(out).drawBitmap(src, 0f, 0f, paint)
        return out
    }
}

object Pipeline {
    fun render(src: Bitmap, st: EditState): Bitmap {
        var b = src
        val rot = st.rotation % 4
        if (rot != 0) b = ImageUtils.rotate(b, rot * 90f)
        if (st.flipH || st.flipV) b = ImageUtils.flip(b, st.flipH, st.flipV)
        val r = st.crop.ratio
        if (r != null) b = ImageUtils.cropCenter(b, if (b.height > b.width) 1f / r else r)
        if (st.enhance) b = Enhancer.autoEnhance(b)
        if (!Adjuster.isNeutral(st)) b = Adjuster.apply(b, st)
        if (st.sharpness > 0.005f) b = Enhancer.sharpen(b, st.sharpness * 0.8f)
        val p = st.preset
        if (p != null && st.intensity > 0f) b = FilterEngine.apply(b, p, st.intensity)
        if (st.watermark) b = Watermarker.apply(b, st.wmPos, st.wmSize)
        if (st.frame != FrameStyle.NONE) b = Framer.apply(b, st.frame)
        return b
    }
}

enum class FrameStyle(@StringRes val label: Int) {
    NONE(R.string.frame_none),
    WHITE(R.string.frame_white),
    INSTANT(R.string.frame_instant),
    BLACK(R.string.frame_black),
    FILM(R.string.frame_film)
}

/** Adds a border around the photo (the output is larger than the input). */
object Framer {
    fun apply(src: Bitmap, style: FrameStyle): Bitmap {
        if (style == FrameStyle.NONE) return src
        val w = src.width
        val h = src.height
        val s = min(w, h)
        val side = (s * (if (style == FrameStyle.FILM) 0.07f else 0.04f)).toInt().coerceAtLeast(4)
        val bottom = if (style == FrameStyle.INSTANT) (s * 0.16f).toInt().coerceAtLeast(8) else side
        val out = Bitmap.createBitmap(w + 2 * side, h + side + bottom, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val light = style == FrameStyle.WHITE || style == FrameStyle.INSTANT
        c.drawColor(if (light) Color.rgb(250, 248, 243) else Color.rgb(14, 14, 14))
        c.drawBitmap(src, side.toFloat(), side.toFloat(), null)
        if (style == FrameStyle.FILM) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = Color.rgb(235, 232, 224)
            val hs = side * 0.4f
            val step = hs * 2.4f
            val topY = side / 2f
            val botY = h + side + side / 2f
            val maxX = (w + side).toFloat()
            var x = side + step * 0.5f
            while (x + hs < maxX) {
                val r = hs * 0.25f
                c.drawRoundRect(RectF(x, topY - hs / 2f, x + hs, topY + hs / 2f), r, r, p)
                c.drawRoundRect(RectF(x, botY - hs / 2f, x + hs, botY + hs / 2f), r, r, p)
                x += step
            }
        }
        return out
    }
}

/** Draws a small lens ring + "Mira Camera" text onto a copy of the photo. */
object Watermarker {
    fun apply(src: Bitmap, pos: Int, size: Float): Bitmap {
        val out = src.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val shortSide = min(out.width, out.height).toFloat()
        val textSize = shortSide * size
        val white = Color.argb(235, 255, 255, 255)
        val shadow = Color.argb(170, 0, 0, 0)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = white
        paint.textSize = textSize
        paint.typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        paint.setShadowLayer(textSize * 0.15f, 0f, 0f, shadow)

        val label = "Mira Camera"
        val tw = paint.measureText(label)
        val ringR = textSize * 0.55f
        val gap = textSize * 0.45f
        val blockW = ringR * 2f + gap + tw
        val blockH = ringR * 2f
        val pad = shortSide * 0.035f
        val x = when (pos) {
            1 -> (out.width - blockW) / 2f
            2, 4 -> out.width - pad - blockW
            else -> pad
        }
        val y = if (pos == 3 || pos == 4) pad else out.height - pad - blockH

        val ring = Paint(Paint.ANTI_ALIAS_FLAG)
        ring.style = Paint.Style.STROKE
        ring.strokeWidth = textSize * 0.1f
        ring.color = white
        ring.setShadowLayer(textSize * 0.15f, 0f, 0f, shadow)
        c.drawCircle(x + ringR, y + ringR, ringR * 0.85f, ring)

        val dot = Paint(Paint.ANTI_ALIAS_FLAG)
        dot.color = white
        c.drawCircle(x + ringR * 1.3f, y + ringR * 0.7f, ringR * 0.14f, dot)

        c.drawText(label, x + ringR * 2f + gap, y + ringR + textSize * 0.33f, paint)
        return out
    }
}
