package com.mira.camera

import android.content.Context
import java.util.Locale

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("mira_prefs", Context.MODE_PRIVATE)

    fun language(c: Context): String =
        sp(c).getString("lang", null) ?: if (Locale.getDefault().language == "th") "th" else "en"

    fun setLanguage(c: Context, v: String) = sp(c).edit().putString("lang", v).apply()

    /** 0 = high, 1 = standard, 2 = data saver */
    fun quality(c: Context): Int = sp(c).getInt("quality", 0)
    fun setQuality(c: Context, v: Int) = sp(c).edit().putInt("quality", v).apply()

    fun jpegQuality(c: Context): Int = when (quality(c)) {
        0 -> 95
        1 -> 85
        else -> 70
    }

    fun maxSide(c: Context): Int = when (quality(c)) {
        0 -> 4096
        1 -> 3072
        else -> 2048
    }

    fun saveToGallery(c: Context): Boolean = sp(c).getBoolean("gallery", true)
    fun setSaveToGallery(c: Context, v: Boolean) = sp(c).edit().putBoolean("gallery", v).apply()

    fun defaultIntensity(c: Context): Float = sp(c).getFloat("intensity", 0.8f)
    fun setDefaultIntensity(c: Context, v: Float) = sp(c).edit().putFloat("intensity", v).apply()

    /** 0 = off, 1 = rule of thirds, 2 = golden ratio */
    fun grid(c: Context): Int = sp(c).getInt("grid", 0)
    fun setGrid(c: Context, v: Int) = sp(c).edit().putInt("grid", v).apply()

    fun keepOriginal(c: Context): Boolean = sp(c).getBoolean("keep_original", true)
    fun setKeepOriginal(c: Context, v: Boolean) = sp(c).edit().putBoolean("keep_original", v).apply()

    fun watermark(c: Context): Boolean = sp(c).getBoolean("watermark", false)
    fun setWatermark(c: Context, v: Boolean) = sp(c).edit().putBoolean("watermark", v).apply()

    fun setReopenSettings(c: Context, v: Boolean) = sp(c).edit().putBoolean("reopen_settings", v).apply()
    fun consumeReopenSettings(c: Context): Boolean {
        val v = sp(c).getBoolean("reopen_settings", false)
        if (v) setReopenSettings(c, false)
        return v
    }
}
