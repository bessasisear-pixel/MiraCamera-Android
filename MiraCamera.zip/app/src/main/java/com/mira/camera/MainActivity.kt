package com.mira.camera

import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import java.io.File
import java.util.Locale

sealed interface Screen {
    object Splash : Screen
    object Camera : Screen
    object Album : Screen
    object Settings : Screen
    object CameraInfo : Screen
    object Guide : Screen
    class Caption(val path: String?) : Screen
    class Editor(
        val uri: Uri,
        val fromCamera: Boolean,
        val startTab: Int,
        val backTo: Screen,
        val presetId: String? = null,
        val intensity: Float? = null
    ) : Screen
    class Preview(val path: String) : Screen
}

class MainActivity : ComponentActivity() {

    override fun attachBaseContext(newBase: Context) {
        val locale = Locale(Prefs.language(newBase))
        Locale.setDefault(locale)
        val cfg = Configuration(newBase.resources.configuration)
        cfg.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        val reopenSettings = Prefs.consumeReopenSettings(this)
        setContent {
            MiraTheme {
                MiraApp(reopenSettings)
            }
        }
    }
}

@Composable
fun MiraApp(reopenSettings: Boolean) {
    var screen by remember {
        mutableStateOf<Screen>(if (reopenSettings) Screen.Settings else Screen.Splash)
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MiraColors.Bg,
        contentColor = MiraColors.Text
    ) {
        androidx.compose.foundation.layout.Box(Modifier.fillMaxSize().systemBarsPadding()) {
            when (val s = screen) {
                Screen.Splash -> SplashScreen { screen = Screen.Camera }

                Screen.Camera -> CameraScreen(
                    onCaptured = { file, presetId, intensity ->
                        screen = Screen.Editor(Uri.fromFile(file), true, 0, Screen.Camera, presetId, intensity)
                    },
                    onOpenAlbum = { screen = Screen.Album },
                    onOpenSettings = { screen = Screen.Settings },
                    onOpenGuide = { screen = Screen.Guide },
                    onPicked = { uri -> screen = Screen.Editor(uri, false, 1, Screen.Camera) }
                )

                Screen.Album -> {
                    BackHandler { screen = Screen.Camera }
                    AlbumScreen(
                        onBack = { screen = Screen.Camera },
                        onOpen = { f -> screen = Screen.Preview(f.absolutePath) },
                        onCaption = { screen = Screen.Caption(null) }
                    )
                }

                is Screen.Preview -> {
                    BackHandler { screen = Screen.Album }
                    PreviewScreen(
                        path = s.path,
                        onBack = { screen = Screen.Album },
                        onEdit = { f -> screen = Screen.Editor(Uri.fromFile(f), false, 1, s) },
                        onCaption = { screen = Screen.Caption(s.path) },
                        onDeleted = { screen = Screen.Album }
                    )
                }

                Screen.Settings -> {
                    BackHandler { screen = Screen.Camera }
                    SettingsScreen(
                        onBack = { screen = Screen.Camera },
                        onOpenCameraInfo = { screen = Screen.CameraInfo }
                    )
                }

                is Screen.Caption -> {
                    val back = if (s.path != null) Screen.Preview(s.path) else Screen.Album
                    BackHandler { screen = back }
                    CaptionScreen(initialPath = s.path, onBack = { screen = back })
                }

                Screen.Guide -> {
                    BackHandler { screen = Screen.Camera }
                    GuideScreen(onBack = { screen = Screen.Camera })
                }

                Screen.CameraInfo -> {
                    BackHandler { screen = Screen.Settings }
                    CameraInfoScreen(onBack = { screen = Screen.Settings })
                }

                is Screen.Editor -> {
                    val discardTemp = {
                        if (s.fromCamera) s.uri.path?.let { File(it).delete() }
                        Unit
                    }
                    EditorScreen(
                        uri = s.uri,
                        fromCamera = s.fromCamera,
                        startTab = s.startTab,
                        presetId = s.presetId,
                        initialIntensity = s.intensity,
                        onClose = { discardTemp(); screen = s.backTo },
                        onSaved = {
                            discardTemp()
                            screen = if (s.fromCamera) Screen.Camera else Screen.Album
                        }
                    )
                }
            }
        }
    }
}
