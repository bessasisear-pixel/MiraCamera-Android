package com.mira.camera

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.widget.Toast
import androidx.camera.core.CameraSelector
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.sqrt

/** Raw facts about the cameras Android exposes to this app. No claims, no interpretation. */
object CameraDiagnostics {

    fun build(ctx: Context): String {
        val sb = StringBuilder()
        sb.appendLine("Device: " + Build.MANUFACTURER + " " + Build.MODEL)
        sb.appendLine("Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")")
        val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
        if (mgr == null) {
            sb.appendLine("No camera service available.")
            return sb.toString()
        }
        val ids: List<String> = try {
            mgr.cameraIdList.toList()
        } catch (e: Exception) {
            sb.appendLine("Could not list cameras: " + e.javaClass.simpleName)
            return sb.toString()
        }
        sb.appendLine("Camera IDs visible to apps: " + ids.joinToString(", "))
        sb.appendLine()
        for (id in ids) describe(mgr, id, sb, "", false)
        return sb.toString()
    }

    /** True when Android exposes exactly one camera for that facing and it has no hidden physical lenses. */
    fun hasSingleExposedLens(ctx: Context, front: Boolean): Boolean {
        val mgr = ctx.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return false
        return try {
            val want = if (front) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK
            val matching = mgr.cameraIdList.filter {
                mgr.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == want
            }
            matching.size == 1 && mgr.getCameraCharacteristics(matching[0]).physicalCameraIds.isEmpty()
        } catch (e: Exception) {
            false
        }
    }

    private fun describe(mgr: CameraManager, id: String, sb: StringBuilder, indent: String, physical: Boolean) {
        val c: CameraCharacteristics = try {
            mgr.getCameraCharacteristics(id)
        } catch (e: Exception) {
            sb.appendLine(indent + "Camera " + id + ": cannot read (" + e.javaClass.simpleName + ")")
            return
        }

        val facing = when (c.get(CameraCharacteristics.LENS_FACING)) {
            CameraCharacteristics.LENS_FACING_FRONT -> "FRONT"
            CameraCharacteristics.LENS_FACING_BACK -> "BACK"
            CameraCharacteristics.LENS_FACING_EXTERNAL -> "EXTERNAL"
            else -> "unknown"
        }
        val label = if (physical) "Physical camera " else "Camera "
        sb.appendLine(indent + label + id + "  facing=" + facing)

        val focal = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)
        val size = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        if (focal != null && focal.isNotEmpty()) {
            val parts = ArrayList<String>()
            for (f in focal) {
                if (size != null) {
                    val diag = sqrt((size.width * size.width + size.height * size.height).toDouble())
                    val eq = f * 43.27 / diag
                    parts.add(String.format(Locale.US, "%.1fmm (about %.0fmm in 35mm terms)", f, eq))
                } else {
                    parts.add(String.format(Locale.US, "%.1fmm", f))
                }
            }
            sb.appendLine(indent + "  focal length: " + parts.joinToString(", "))
        }

        if (Build.VERSION.SDK_INT >= 30) {
            val r = c.get(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE)
            if (r != null) {
                sb.appendLine(indent + "  zoom ratio range: " + r.lower + " .. " + r.upper)
            }
        }
        val maxDigital = c.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM)
        if (maxDigital != null) sb.appendLine(indent + "  max digital zoom: " + maxDigital)

        val flash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
        if (flash != null) sb.appendLine(indent + "  flash unit: " + flash)

        val orientation = c.get(CameraCharacteristics.SENSOR_ORIENTATION)
        if (orientation != null) sb.appendLine(indent + "  sensor orientation: " + orientation)

        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
        val best = map?.getOutputSizes(ImageFormat.JPEG)?.maxByOrNull { it.width.toLong() * it.height }
        if (best != null) {
            val mp = best.width.toLong() * best.height / 1e6
            sb.appendLine(indent + "  largest JPEG: " + best.width + "x" + best.height +
                String.format(Locale.US, " (%.1f MP)", mp))
        }

        if (!physical) {
            val caps = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            val logical = caps?.contains(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES_LOGICAL_MULTI_CAMERA) == true
            val phys = c.physicalCameraIds
            if (logical || phys.isNotEmpty()) {
                sb.appendLine(indent + "  logical multi-camera, physical IDs: " + phys.joinToString(", "))
                for (p in phys) describe(mgr, p, sb, indent + "    ", true)
            }
        }
        sb.appendLine()
    }
}

@Composable
fun CameraInfoScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var report by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        val base = withContext(Dispatchers.Default) { CameraDiagnostics.build(ctx) }
        val camerax = try {
            val p = ctx.awaitCameraProvider()
            "CameraX: availableCameraInfos=" + p.availableCameraInfos.size +
                ", back=" + p.hasCamera(CameraSelector.DEFAULT_BACK_CAMERA) +
                ", front=" + p.hasCamera(CameraSelector.DEFAULT_FRONT_CAMERA)
        } catch (e: Exception) {
            "CameraX: could not initialise (" + e.javaClass.simpleName + ")"
        }
        report = base + camerax + "\n"
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.set_camera_info), onBack)
        Text(
            stringResource(R.string.caminfo_desc),
            fontSize = 12.sp,
            color = MiraColors.TextDim,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        Box(Modifier.weight(1f).fillMaxWidth().padding(16.dp), contentAlignment = Alignment.TopStart) {
            val text = report
            if (text == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = MiraColors.Accent)
                }
            } else {
                SelectionContainer {
                    Text(
                        text,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        modifier = Modifier.verticalScroll(rememberScrollState())
                    )
                }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Pill(stringResource(R.string.action_copy), enabled = report != null, onClick = {
                val text = report ?: return@Pill
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("Mira Camera info", text))
                Toast.makeText(ctx, ctx.getString(R.string.caminfo_copied), Toast.LENGTH_SHORT).show()
            })
            Pill(stringResource(R.string.action_share), enabled = report != null, onClick = {
                val text = report ?: return@Pill
                try {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    ctx.startActivity(Intent.createChooser(send, ctx.getString(R.string.action_share)))
                } catch (e: Exception) {
                    Toast.makeText(ctx, ctx.getString(R.string.prev_share_failed), Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}
