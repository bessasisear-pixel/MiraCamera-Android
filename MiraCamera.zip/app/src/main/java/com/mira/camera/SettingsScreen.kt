package com.mira.camera

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

private fun cacheBytes(ctx: Context): Long =
    ctx.cacheDir.walkTopDown().filter { it.isFile }.sumOf { it.length() }

private fun formatSize(bytes: Long): String =
    if (bytes < 1024 * 1024) "${bytes / 1024} KB" else String.format("%.1f MB", bytes / 1048576.0)

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(MiraColors.Surface)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
fun SettingsScreen(onBack: () -> Unit, onOpenCameraInfo: () -> Unit) {
    val ctx = LocalContext.current

    var lang by remember { mutableStateOf(Prefs.language(ctx)) }
    var quality by remember { mutableIntStateOf(Prefs.quality(ctx)) }
    var gallery by remember { mutableStateOf(Prefs.saveToGallery(ctx)) }
    var keepOriginal by remember { mutableStateOf(Prefs.keepOriginal(ctx)) }
    var watermark by remember { mutableStateOf(Prefs.watermark(ctx)) }
    var intensity by remember { mutableFloatStateOf(Prefs.defaultIntensity(ctx)) }
    var cacheSize by remember { mutableStateOf(formatSize(cacheBytes(ctx))) }
    var showPrivacy by remember { mutableStateOf(false) }

    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (e: Exception) {
            ""
        }
    }

    fun changeLanguage(code: String) {
        if (code == lang) return
        Prefs.setLanguage(ctx, code)
        Prefs.setReopenSettings(ctx, true)
        lang = code
        ctx.findActivity()?.recreate()
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.set_title), onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Section(stringResource(R.string.set_language)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Pill("ไทย", onClick = { changeLanguage("th") }, selected = lang == "th")
                    Pill("English", onClick = { changeLanguage("en") }, selected = lang == "en")
                }
            }

            Section(stringResource(R.string.set_quality)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(R.string.q_high, R.string.q_standard, R.string.q_saver).forEachIndexed { i, res ->
                        Pill(stringResource(res), selected = quality == i, onClick = {
                            quality = i
                            Prefs.setQuality(ctx, i)
                        })
                    }
                }
                Text(stringResource(R.string.set_quality_desc), fontSize = 12.sp, color = MiraColors.TextDim)
            }

            Section(stringResource(R.string.set_gallery)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.set_gallery_desc),
                        fontSize = 12.sp,
                        color = MiraColors.TextDim,
                        modifier = Modifier.weight(1f).padding(end = 12.dp)
                    )
                    Switch(checked = gallery, onCheckedChange = {
                        gallery = it
                        Prefs.setSaveToGallery(ctx, it)
                    })
                }
            }

            Section(stringResource(R.string.set_keep_original)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.set_keep_original_desc),
                        fontSize = 12.sp,
                        color = MiraColors.TextDim,
                        modifier = Modifier.weight(1f).padding(end = 12.dp)
                    )
                    Switch(checked = keepOriginal, onCheckedChange = {
                        keepOriginal = it
                        Prefs.setKeepOriginal(ctx, it)
                    })
                }
            }

            Section(stringResource(R.string.set_watermark)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.set_watermark_desc),
                        fontSize = 12.sp,
                        color = MiraColors.TextDim,
                        modifier = Modifier.weight(1f).padding(end = 12.dp)
                    )
                    Switch(checked = watermark, onCheckedChange = {
                        watermark = it
                        Prefs.setWatermark(ctx, it)
                    })
                }
            }

            Section(stringResource(R.string.set_intensity, (intensity * 100).roundToInt())) {
                Slider(value = intensity, onValueChange = {
                    intensity = it
                    Prefs.setDefaultIntensity(ctx, it)
                })
            }

            Section(stringResource(R.string.set_cache)) {
                Text(stringResource(R.string.set_cache_desc, cacheSize), fontSize = 12.sp, color = MiraColors.TextDim)
                Pill(stringResource(R.string.set_cache), onClick = {
                    ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
                    cacheSize = formatSize(cacheBytes(ctx))
                    Toast.makeText(ctx, ctx.getString(R.string.set_cache_cleared), Toast.LENGTH_SHORT).show()
                })
            }

            Section(stringResource(R.string.set_ai)) {
                Text(stringResource(R.string.set_ai_body), fontSize = 13.sp, color = MiraColors.TextDim)
            }

            Section(stringResource(R.string.set_camera_info)) {
                Text(stringResource(R.string.caminfo_desc), fontSize = 12.sp, color = MiraColors.TextDim)
                Pill(stringResource(R.string.set_camera_info), onClick = onOpenCameraInfo)
            }

            Section(stringResource(R.string.set_about)) {
                Text(stringResource(R.string.set_version, version), fontSize = 13.sp, color = MiraColors.TextDim)
                Pill(stringResource(R.string.set_privacy), onClick = { showPrivacy = true })
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    if (showPrivacy) {
        AlertDialog(
            onDismissRequest = { showPrivacy = false },
            title = { Text(stringResource(R.string.set_privacy)) },
            text = { Text(stringResource(R.string.privacy_body), fontSize = 14.sp) },
            confirmButton = {
                TextButton(onClick = { showPrivacy = false }) { Text(stringResource(R.string.action_ok)) }
            }
        )
    }
}
