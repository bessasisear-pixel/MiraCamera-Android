package com.mira.camera

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

private val styleLabels = intArrayOf(
    R.string.cap_style_casual,
    R.string.cap_style_cute,
    R.string.cap_style_travel,
    R.string.cap_style_photography,
    R.string.cap_style_minimal,
    R.string.cap_style_funny,
    R.string.cap_style_inspirational
)

private val captionArrays = arrayOf(
    intArrayOf(
        R.array.cap_en_casual, R.array.cap_en_cute, R.array.cap_en_travel, R.array.cap_en_photography,
        R.array.cap_en_minimal, R.array.cap_en_funny, R.array.cap_en_inspirational
    ),
    intArrayOf(
        R.array.cap_th_casual, R.array.cap_th_cute, R.array.cap_th_travel, R.array.cap_th_photography,
        R.array.cap_th_minimal, R.array.cap_th_funny, R.array.cap_th_inspirational
    )
)

/**
 * Caption helper. These captions come from built-in templates: they are NOT written by AI and do not
 * describe the photo. A real AI caption needs an online vision service that is not connected here.
 */
@Composable
fun CaptionScreen(initialPath: String?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var photoUri by remember { mutableStateOf<Uri?>(initialPath?.let { Uri.fromFile(File(it)) }) }
    var photo by remember { mutableStateOf<Bitmap?>(null) }
    var albumFiles by remember { mutableStateOf<List<File>>(emptyList()) }
    var showAlbum by remember { mutableStateOf(false) }
    var capLang by remember { mutableStateOf(if (Prefs.language(ctx) == "th") "th" else "en") }
    var style by remember { mutableIntStateOf(0) }
    var index by remember { mutableIntStateOf(0) }
    var text by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) photoUri = uri
    }

    LaunchedEffect(photoUri) {
        val u = photoUri
        photo = if (u == null) null else withContext(Dispatchers.IO) { ImageUtils.load(ctx, u, 1024) }
    }
    LaunchedEffect(showAlbum) {
        if (showAlbum && albumFiles.isEmpty()) albumFiles = withContext(Dispatchers.IO) { PhotoStore.list(ctx) }
    }

    val arrayId = captionArrays[if (capLang == "th") 1 else 0][style]
    val templates = stringArrayResource(arrayId)
    LaunchedEffect(arrayId) {
        index = 0
        text = templates[0]
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.cap_title), onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(R.string.cap_notice), fontSize = 12.sp, color = MiraColors.TextDim)

            // Photo (optional, shown for context only; it is not analysed or uploaded)
            val shown = photo
            if (shown != null) {
                Image(
                    bitmap = remember(shown) { shown.asImageBitmap() },
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().height(160.dp).clip(RoundedCornerShape(14.dp))
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(stringResource(R.string.cap_from_album), selected = showAlbum, onClick = { showAlbum = !showAlbum })
                Pill(stringResource(R.string.cap_from_gallery), onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                })
            }
            if (showAlbum) {
                if (albumFiles.isEmpty()) {
                    Text(stringResource(R.string.album_empty), fontSize = 12.sp, color = MiraColors.TextDim)
                } else {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(albumFiles, key = { it.path }) { f ->
                            Thumb(
                                f,
                                Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { photoUri = Uri.fromFile(f) }
                            )
                        }
                    }
                }
            }

            // Language of the caption text
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(stringResource(R.string.cap_language), fontSize = 12.sp, color = MiraColors.TextDim)
                Pill("ไทย", selected = capLang == "th", onClick = { capLang = "th" })
                Pill("English", selected = capLang == "en", onClick = { capLang = "en" })
            }

            // Style
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                styleLabels.forEachIndexed { i, res ->
                    Pill(stringResource(res), selected = style == i, onClick = { style = i })
                }
            }

            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(stringResource(R.string.cap_text_label)) },
                minLines = 3,
                modifier = Modifier.fillMaxWidth()
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill(stringResource(R.string.cap_another), onClick = {
                    index = (index + 1) % templates.size
                    text = templates[index]
                })
                Pill(stringResource(R.string.action_copy), enabled = text.isNotBlank(), onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Mira Camera caption", text))
                    Toast.makeText(ctx, ctx.getString(R.string.cap_copied), Toast.LENGTH_SHORT).show()
                })
                Pill(stringResource(R.string.action_share), enabled = text.isNotBlank(), onClick = {
                    try {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        ctx.startActivity(Intent.createChooser(send, ctx.getString(R.string.action_share)))
                    } catch (e: Exception) {
                        Toast.makeText(ctx, ctx.getString(R.string.prev_share_failed), Toast.LENGTH_SHORT).show()
                    }
                })
            }

            // Honest status of real AI captions
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(MiraColors.Surface)
                    .padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.cap_ai_title),
                        modifier = Modifier.weight(1f),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(stringResource(R.string.ai_status), color = MiraColors.Accent, fontSize = 12.sp)
                }
                Text(stringResource(R.string.cap_ai_body), fontSize = 12.sp, color = MiraColors.TextDim)
            }
            Box(Modifier.height(16.dp))
        }
    }
}
