package com.mira.camera

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.stringArrayResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class GuideTopic(val title: Int, val tips: Int, val diagram: Int)

/** Static, rules-based photography tips with simple original diagrams. This is not AI analysis. */
@Composable
fun GuideScreen(onBack: () -> Unit) {
    val topics = remember {
        listOf(
            GuideTopic(R.string.guide_portrait, R.array.tips_portrait, 0),
            GuideTopic(R.string.guide_couple, R.array.tips_couple, 1),
            GuideTopic(R.string.guide_group, R.array.tips_group, 2),
            GuideTopic(R.string.guide_fullbody, R.array.tips_fullbody, 3),
            GuideTopic(R.string.guide_seated, R.array.tips_seated, 6),
            GuideTopic(R.string.guide_standing, R.array.tips_standing, 7),
            GuideTopic(R.string.guide_landscape, R.array.tips_landscape, 4),
            GuideTopic(R.string.guide_angles, R.array.tips_angles, 5)
        )
    }
    var open by remember { mutableIntStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.guide_title), onBack)
        Column(
            Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(stringResource(R.string.guide_notice), fontSize = 12.sp, color = MiraColors.TextDim)
            topics.forEachIndexed { i, t ->
                Column(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MiraColors.Surface)
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { open = if (open == i) -1 else i }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            stringResource(t.title),
                            modifier = Modifier.weight(1f),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(if (open == i) "−" else "+", color = MiraColors.Accent, fontSize = 20.sp)
                    }
                    if (open == i) {
                        Column(
                            Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            GuideDiagram(t.diagram, Modifier.fillMaxWidth().height(150.dp))
                            stringArrayResource(t.tips).forEachIndexed { n, tip ->
                                Text((n + 1).toString() + ". " + tip, fontSize = 14.sp)
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

private fun DrawScope.person(cx: Float, headY: Float, r: Float, body: Float, legs: Float, color: Color) {
    val sw = 4f
    drawCircle(color, r, Offset(cx, headY), style = Stroke(sw))
    val neck = headY + r
    val hip = neck + body
    drawLine(color, Offset(cx, neck), Offset(cx, hip), strokeWidth = sw)
    drawLine(color, Offset(cx - r * 1.6f, neck + r * 0.6f), Offset(cx + r * 1.6f, neck + r * 0.6f), strokeWidth = sw)
    if (legs > 0f) {
        drawLine(color, Offset(cx, hip), Offset(cx - r * 0.9f, hip + body * legs), strokeWidth = sw)
        drawLine(color, Offset(cx, hip), Offset(cx + r * 0.9f, hip + body * legs), strokeWidth = sw)
    }
}

@Composable
private fun GuideDiagram(kind: Int, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val dim = Color(0x33FFFFFF)
        val ink = Color(0xFFECE9E2)
        val acc = Color(0xFFE6C58B)

        drawRoundRect(color = Color(0xFF0E0F11), size = size, cornerRadius = CornerRadius(16f, 16f))
        for (i in 1..2) {
            drawLine(dim, Offset(w * i / 3f, 0f), Offset(w * i / 3f, h), strokeWidth = 1.5f)
            drawLine(dim, Offset(0f, h * i / 3f), Offset(w, h * i / 3f), strokeWidth = 1.5f)
        }

        when (kind) {
            0 -> { // portrait: eyes on the upper third line
                drawLine(acc, Offset(0f, h / 3f), Offset(w, h / 3f), strokeWidth = 4f)
                person(w * 0.5f, h * 0.30f, h * 0.12f, h * 0.45f, 0f, ink)
            }
            1 -> { // couple: close together, similar height
                person(w * 0.43f, h * 0.30f, h * 0.10f, h * 0.45f, 0f, ink)
                person(w * 0.57f, h * 0.33f, h * 0.10f, h * 0.45f, 0f, ink)
            }
            2 -> { // group: staggered rows
                val r = h * 0.07f
                for (x in listOf(0.30f, 0.50f, 0.70f)) person(w * x, h * 0.26f, r, h * 0.12f, 0f, ink)
                for (x in listOf(0.40f, 0.60f)) person(w * x, h * 0.50f, r, h * 0.12f, 0f, ink)
            }
            3 -> { // full body: space above head and below feet
                drawLine(acc, Offset(w * 0.3f, h * 0.07f), Offset(w * 0.7f, h * 0.07f), strokeWidth = 3f)
                drawLine(acc, Offset(w * 0.3f, h * 0.93f), Offset(w * 0.7f, h * 0.93f), strokeWidth = 3f)
                person(w * 0.5f, h * 0.20f, h * 0.07f, h * 0.30f, 1f, ink)
            }
            4 -> { // landscape: horizon on a third line, subject on a power point
                drawLine(acc, Offset(0f, h * 2f / 3f), Offset(w, h * 2f / 3f), strokeWidth = 4f)
                val path = Path()
                path.moveTo(0f, h * 2f / 3f)
                path.lineTo(w * 0.2f, h * 0.45f)
                path.lineTo(w * 0.35f, h * 0.58f)
                path.lineTo(w * 0.55f, h * 0.36f)
                path.lineTo(w * 0.8f, h * 2f / 3f)
                drawPath(path, ink, style = Stroke(4f))
                drawCircle(acc, h * 0.07f, Offset(w * 2f / 3f, h / 3f))
                drawCircle(ink, h * 0.05f, Offset(w * 0.18f, h * 0.84f))
            }
            6 -> { // seated: relaxed lean, knees angled, chair for context
                val cx = w * 0.45f
                val r = h * 0.09f
                drawCircle(ink, r, Offset(cx, h * 0.24f), style = Stroke(4f))
                drawLine(ink, Offset(cx, h * 0.24f + r), Offset(cx, h * 0.58f), strokeWidth = 4f)
                drawLine(ink, Offset(cx - r * 1.5f, h * 0.24f + r * 1.5f), Offset(cx + r * 1.5f, h * 0.24f + r * 1.5f), strokeWidth = 4f)
                drawLine(ink, Offset(cx, h * 0.58f), Offset(w * 0.68f, h * 0.58f), strokeWidth = 4f)
                drawLine(ink, Offset(w * 0.68f, h * 0.58f), Offset(w * 0.68f, h * 0.86f), strokeWidth = 4f)
                drawLine(acc, Offset(w * 0.34f, h * 0.62f), Offset(w * 0.74f, h * 0.62f), strokeWidth = 3f)
                drawLine(acc, Offset(w * 0.36f, h * 0.62f), Offset(w * 0.36f, h * 0.9f), strokeWidth = 3f)
            }
            7 -> { // standing: weight on one leg, relaxed knee
                val cx = w * 0.5f
                val r = h * 0.07f
                val headY = h * 0.2f
                val hip = headY + r + h * 0.3f
                drawCircle(ink, r, Offset(cx, headY), style = Stroke(4f))
                drawLine(ink, Offset(cx, headY + r), Offset(cx, hip), strokeWidth = 4f)
                drawLine(ink, Offset(cx - r * 1.7f, headY + r * 1.6f), Offset(cx + r * 1.7f, headY + r * 1.6f), strokeWidth = 4f)
                drawLine(ink, Offset(cx, hip), Offset(cx - r * 0.6f, hip + h * 0.28f), strokeWidth = 4f)
                drawLine(ink, Offset(cx, hip), Offset(cx + r * 1.9f, hip + h * 0.24f), strokeWidth = 4f)
                drawLine(acc, Offset(cx - r * 0.6f, hip + h * 0.28f), Offset(cx - r * 0.6f, h * 0.1f), strokeWidth = 2f)
            }
            else -> { // camera angles around one subject
                val headX = w * 0.3f
                val headY = h * 0.32f
                person(headX, headY, h * 0.08f, h * 0.25f, 0.8f, ink)
                for (y in listOf(0.12f, 0.32f, 0.82f)) {
                    drawLine(acc, Offset(w * 0.8f, h * y), Offset(headX + h * 0.1f, headY), strokeWidth = 2.5f)
                    drawCircle(acc, h * 0.035f, Offset(w * 0.8f, h * y))
                }
            }
        }
    }
}
