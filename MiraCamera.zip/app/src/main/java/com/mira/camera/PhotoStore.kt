package com.mira.camera

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.ExifInterface
import android.os.Build
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PhotoStore {

    class SaveResult(val file: File?, val galleryOk: Boolean, val error: Boolean)

    fun albumDir(c: Context): File = File(c.filesDir, "album").also { it.mkdirs() }

    fun list(c: Context): List<File> =
        albumDir(c).listFiles { f -> f.isFile && f.extension.equals("jpg", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    fun originalsDir(c: Context): File = File(c.filesDir, "originals").also { it.mkdirs() }

    /** The untouched photo stored for an album photo, if the user kept originals. */
    fun originalOf(c: Context, album: File): File? =
        File(originalsDir(c), album.name).takeIf { it.isFile }

    /** Deletes the album photo and its stored original. The phone-gallery copy is not touched. */
    fun delete(c: Context, album: File): Boolean {
        val ok = album.delete() || !album.exists()
        File(originalsDir(c), album.name).delete()
        return ok
    }

    /**
     * Always saves to the in-app album; also saves to the phone gallery when enabled in Settings.
     * If [originalSource] is given, the untouched file is copied into private storage next to it.
     */
    fun save(c: Context, bmp: Bitmap, originalSource: File? = null, marks: String = ""): SaveResult {
        val bytes = try {
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, Prefs.jpegQuality(c), bos)
            bos.toByteArray()
        } catch (e: Exception) {
            return SaveResult(null, false, true)
        }

        val name = "MIRA_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + ".jpg"
        val file = File(albumDir(c), name)
        try {
            file.outputStream().use { it.write(bytes) }
        } catch (e: IOException) {
            file.delete()
            return SaveResult(null, false, true)
        }

        writeExif(file, originalSource, marks)

        if (originalSource != null && originalSource.isFile) {
            try {
                originalSource.copyTo(File(originalsDir(c), name), overwrite = true)
            } catch (e: Exception) {
                // The edited photo is already saved; losing the original copy is not fatal.
            }
        }

        var galleryOk = true
        if (Prefs.saveToGallery(c)) {
            val finalBytes = try {
                file.readBytes()
            } catch (e: Exception) {
                bytes
            }
            galleryOk = saveToGallery(c, name, finalBytes)
        }
        return SaveResult(file, galleryOk, false)
    }

    /** Writes capture date, software, device make/model and normal orientation. No location is stored. */
    private fun writeExif(file: File, originalSource: File?, marks: String) {
        try {
            val fmt = SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
            var taken: String? = null
            if (originalSource != null && originalSource.isFile) {
                try {
                    taken = ExifInterface(originalSource.absolutePath)
                        .getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                } catch (e: Exception) {
                    // no date available in the original
                }
            }
            val now = fmt.format(Date())
            val ex = ExifInterface(file.absolutePath)
            ex.setAttribute(ExifInterface.TAG_DATETIME, now)
            ex.setAttribute(ExifInterface.TAG_DATETIME_ORIGINAL, taken ?: now)
            ex.setAttribute(ExifInterface.TAG_SOFTWARE, "Mira Camera")
            ex.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, ("Mira Camera " + marks).trim())
            ex.setAttribute(ExifInterface.TAG_MAKE, Build.MANUFACTURER)
            ex.setAttribute(ExifInterface.TAG_MODEL, Build.MODEL)
            ex.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
            ex.saveAttributes()
        } catch (e: Exception) {
            // Metadata is best-effort; the photo itself is already saved.
        }
    }

    private fun saveToGallery(c: Context, name: String, bytes: ByteArray): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MiraCamera")
            put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = c.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = resolver.openOutputStream(uri) ?: throw IOException("No output stream")
            stream.use { it.write(bytes) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } catch (e: Exception) {
            try {
                resolver.delete(uri, null, null)
            } catch (ignored: Exception) {
            }
            false
        }
    }

    fun share(c: Context, file: File): Boolean {
        return try {
            val uri = FileProvider.getUriForFile(c, c.packageName + ".fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            c.startActivity(Intent.createChooser(send, c.getString(R.string.prev_share_chooser)))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun formatDate(c: Context, millis: Long): String =
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale(Prefs.language(c)))
            .format(Date(millis))
}
