package com.mira.camera

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object PhotoStore {

    class SaveResult(val file: File?, val galleryOk: Boolean, val error: Boolean)

    fun albumDir(c: Context): File = File(c.filesDir, "album").also { it.mkdirs() }

    fun list(c: Context): List<File> =
        albumDir(c).listFiles { f -> f.isFile && f.extension.equals("jpg", true) }
            ?.sortedByDescending { it.lastModified() }
            ?: emptyList()

    /** Always saves to the in-app album; also saves to the phone gallery when enabled in Settings. */
    fun save(c: Context, bmp: Bitmap): SaveResult {
        val bytes = try {
            val bos = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.JPEG, Prefs.jpegQuality(c), bos)
            bos.toByteArray()
        } catch (e: Exception) {
            return SaveResult(null, false, true)
        }

        val name = "MIRA_" + SimpleDateFormat("yyyyMMdd_HHmmss_SSS", Locale.US).format(Date()) + ".jpg"
        val file = File(albumDir(c), name)
        try {
            file.outputStream().use { it.write(bytes) }
        } catch (e: IOException) {
            file.delete()
            return SaveResult(null, false, true)
        }

        var galleryOk = true
        if (Prefs.saveToGallery(c)) galleryOk = saveToGallery(c, name, bytes)
        return SaveResult(file, galleryOk, false)
    }

    private fun saveToGallery(c: Context, name: String, bytes: ByteArray): Boolean {
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/MiraCamera")
            put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = c.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        return try {
            val stream = resolver.openOutputStream(uri) ?: throw IOException("No output stream")
            stream.use { it.write(bytes) }
            values.clear()
            values.put(MediaStore.Images.Media.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            true
        } catch (e: Exception) {
            try {
                resolver.delete(uri, null, null)
            } catch (ignored: Exception) {
            }
            false
        }
    }

    fun share(c: Context, file: File): Boolean {
        return try {
            val uri = FileProvider.getUriForFile(c, c.packageName + ".fileprovider", file)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/jpeg"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            c.startActivity(Intent.createChooser(send, c.getString(R.string.prev_share_chooser)))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun formatDate(c: Context, millis: Long): String =
        DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Locale(Prefs.language(c)))
            .format(Date(millis))
}
