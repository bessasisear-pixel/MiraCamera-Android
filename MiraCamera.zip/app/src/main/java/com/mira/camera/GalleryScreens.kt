package com.mira.camera

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun AlbumScreen(onBack: () -> Unit, onOpen: (File) -> Unit) {
    val ctx = LocalContext.current
    var files by remember { mutableStateOf<List<File>?>(null) }
    LaunchedEffect(Unit) {
        files = withContext(Dispatchers.IO) { PhotoStore.list(ctx) }
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(stringResource(R.string.album_title), onBack)
        val list = files
        when {
            list == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MiraColors.Accent)
            }
            list.isEmpty() -> Box(Modifier.fillMaxSize().padding(32.dp), contentAlignment = Alignment.Center) {
                Text(
                    stringResource(R.string.album_empty),
                    color = MiraColors.TextDim,
                    textAlign = TextAlign.Center
                )
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Adaptive(108.dp),
                contentPadding = PaddingValues(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(list, key = { it.path }) { f ->
                    Thumb(
                        f,
                        Modifier
                            .aspectRatio(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onOpen(f) }
                    )
                }
            }
        }
    }
}

@Composable
fun PreviewScreen(
    path: String,
    onBack: () -> Unit,
    onEdit: (File) -> Unit,
    onDeleted: () -> Unit
) {
    val ctx = LocalContext.current
    val file = remember(path) { File(path) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var missing by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    LaunchedEffect(path) {
        val b = withContext(Dispatchers.IO) {
            if (file.exists()) ImageUtils.load(ctx, Uri.fromFile(file), 2048) else null
        }
        if (b == null) missing = true else bmp = b
    }

    Column(Modifier.fillMaxSize()) {
        TopBar(
            title = if (file.exists()) {
                stringResource(R.string.prev_saved_on, PhotoStore.formatDate(ctx, file.lastModified()))
            } else {
                stringResource(R.string.album_missing)
            },
            onBack = onBack
        )

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(1f, 5f)
                        offset = if (scale == 1f) Offset.Zero else offset + pan
                    }
                },
            contentAlignment = Alignment.Center
        ) {
            val image = bmp
            if (image != null) {
                Image(
                    bitmap = remember(image) { image.asImageBitmap() },
                    contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offset.x
                            translationY = offset.y
                        }
                )
            } else if (missing) {
                Text(
                    stringResource(R.string.prev_missing),
                    color = MiraColors.TextDim,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(32.dp)
                )
            } else {
                CircularProgressIndicator(color = MiraColors.Accent)
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            Pill(stringResource(R.string.action_share), enabled = bmp != null, onClick = {
                if (!PhotoStore.share(ctx, file)) {
                    Toast.makeText(ctx, ctx.getString(R.string.prev_share_failed), Toast.LENGTH_SHORT).show()
                }
            })
            Pill(stringResource(R.string.action_edit), enabled = bmp != null, onClick = { onEdit(file) })
            Pill(stringResource(R.string.action_delete), onClick = { confirmDelete = true })
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text(stringResource(R.string.prev_delete_title)) },
            text = { Text(stringResource(R.string.prev_delete_body), fontSize = 14.sp) },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    if (file.delete() || !file.exists()) {
                        onDeleted()
                    } else {
                        Toast.makeText(ctx, ctx.getString(R.string.prev_delete_failed), Toast.LENGTH_SHORT).show()
                    }
                }) { Text(stringResource(R.string.action_delete), color = MiraColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmDelete = false }) {
                    Text(stringResource(R.string.action_cancel))
                }
            }
        )
    }
}
