package com.mira.camera

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.core.ZoomState
import androidx.camera.view.PreviewView
import android.graphics.Bitmap
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.layout.ContentScale
import java.util.concurrent.Executors
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.lifecycle.Observer
import java.util.Locale
import kotlin.math.abs
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.coroutines.suspendCoroutine
import kotlin.math.roundToInt

internal suspend fun Context.awaitCameraProvider(): ProcessCameraProvider =
    suspendCoroutine { cont ->
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener(
            {
                try {
                    cont.resume(future.get())
                } catch (e: Exception) {
                    cont.resumeWithException(e)
                }
            },
            ContextCompat.getMainExecutor(this)
        )
    }

/** Settings shared with the camera-analysis thread. */
private class LiveConfig {
    @Volatile var preset: FilterPreset? = null
    @Volatile var intensity: Float = 0.8f
    @Volatile var front: Boolean = false
    @Volatile var lastFrameAt: Long = 0L
}

/** Converts an RGBA_8888 analysis frame to a Bitmap (handles row padding). */
private fun rgbaToBitmap(image: ImageProxy): Bitmap {
    val plane = image.planes[0]
    val buffer = plane.buffer
    buffer.rewind()
    val rowPixels = plane.rowStride / plane.pixelStride
    val padded = Bitmap.createBitmap(rowPixels, image.height, Bitmap.Config.ARGB_8888)
    padded.copyPixelsFromBuffer(buffer)
    return if (rowPixels == image.width) padded
    else Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
}

private fun toast(ctx: Context, msg: String) {
    Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
}

@Composable
fun CameraScreen(
    onCaptured: (File, String?, Float) -> Unit,
    onOpenAlbum: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenGuide: () -> Unit,
    onPicked: (Uri) -> Unit
) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    fun hasPermission() =
        ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

    var granted by remember { mutableStateOf(hasPermission()) }
    var asked by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { ok ->
        granted = ok
        asked = true
    }
    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) onPicked(uri)
    }

    LaunchedEffect(Unit) {
        if (!granted) permissionLauncher.launch(Manifest.permission.CAMERA)
    }
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) granted = hasPermission()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    if (!granted) {
        val activity = ctx.findActivity()
        val blocked = asked && activity != null &&
            !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.CAMERA)
        PermissionView(
            blocked = blocked,
            onGrant = { permissionLauncher.launch(Manifest.permission.CAMERA) },
            onOpenSystemSettings = {
                try {
                    ctx.startActivity(
                        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", ctx.packageName, null))
                    )
                } catch (e: Exception) {
                    // No settings screen available; nothing else we can do.
                }
            },
            onAlbum = onOpenAlbum,
            onAppSettings = onOpenSettings
        )
    } else {
        CameraContent(
            onCaptured = onCaptured,
            onOpenAlbum = onOpenAlbum,
            onOpenSettings = onOpenSettings,
            onOpenGuide = onOpenGuide,
            onPick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
        )
    }
}

@Composable
private fun PermissionView(
    blocked: Boolean,
    onGrant: () -> Unit,
    onOpenSystemSettings: () -> Unit,
    onAlbum: () -> Unit,
    onAppSettings: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        MiraLogo(72.dp)
        Spacer(Modifier.height(24.dp))
        Text(stringResource(R.string.cam_perm_title), fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        Text(
            stringResource(if (blocked) R.string.cam_perm_blocked else R.string.cam_perm_body),
            color = MiraColors.TextDim,
            textAlign = TextAlign.Center,
            fontSize = 14.sp
        )
        Spacer(Modifier.height(24.dp))
        if (blocked) {
            Pill(stringResource(R.string.cam_perm_settings), onClick = onOpenSystemSettings, selected = true)
        } else {
            Pill(stringResource(R.string.cam_perm_grant), onClick = onGrant, selected = true)
        }
        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(stringResource(R.string.cam_album), onClick = onAlbum)
            Pill(stringResource(R.string.set_title), onClick = onAppSettings)
        }
    }
}

@Composable
private fun CameraContent(
    onCaptured: (File, String?, Float) -> Unit,
    onOpenAlbum: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenGuide: () -> Unit,
    onPick: () -> Unit
) {
    val ctx = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    val previewView = remember {
        PreviewView(ctx).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    val providerHolder = remember { arrayOfNulls<ProcessCameraProvider>(1) }
    val boundLens = remember { booleanArrayOf(false) }

    var lensFront by remember { mutableStateOf(false) }
    var flashMode by remember { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var timerSec by remember { mutableIntStateOf(0) }
    var zoomRatio by remember { mutableFloatStateOf(1f) }
    var minZoom by remember { mutableFloatStateOf(1f) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var singleLens by remember { mutableStateOf(false) }
    var gridMode by remember { mutableIntStateOf(Prefs.grid(ctx)) }
    var exposureIdx by remember { mutableIntStateOf(0) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var startError by remember { mutableStateOf<String?>(null) }
    var countdown by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var focusPoint by remember { mutableStateOf<Offset?>(null) }
    var latest by remember { mutableStateOf<File?>(null) }
    var livePresetId by remember { mutableStateOf<String?>(null) }
    var liveBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var liveAvailable by remember { mutableStateOf(true) }
    var assistMode by remember { mutableIntStateOf(0) }
    var showFilters by remember { mutableStateOf(false) }
    var liveIntensity by remember { mutableFloatStateOf(Prefs.defaultIntensity(ctx)) }
    var filterThumbs by remember { mutableStateOf<Map<String, Bitmap>>(emptyMap()) }
    var rollDeg by remember { mutableFloatStateOf(0f) }
    var levelValid by remember { mutableStateOf(false) }
    val liveCfg = remember { LiveConfig() }
    val analysisExecutor = remember { Executors.newSingleThreadExecutor() }

    SideEffect {
        liveCfg.preset = FilterEngine.presets.firstOrNull { it.id == livePresetId }
        liveCfg.intensity = liveIntensity
        liveCfg.front = lensFront
    }

    LaunchedEffect(Unit) {
        latest = withContext(Dispatchers.IO) { PhotoStore.list(ctx).firstOrNull() }
    }

    LaunchedEffect(focusPoint) {
        if (focusPoint != null) {
            delay(900)
            focusPoint = null
        }
    }

    // (Re)bind the camera whenever the lens changes.
    // Re-binds when the lens changes, or when a live filter is switched on/off (analysis is bound only when needed).
    LaunchedEffect(lensFront, livePresetId != null) {
        val wantLive = livePresetId != null
        val keepZoom = zoomRatio
        val sameLens = boundLens[0] == lensFront
        try {
            val provider = ctx.awaitCameraProvider()
            providerHolder[0] = provider
            val selector =
                if (lensFront) CameraSelector.DEFAULT_FRONT_CAMERA else CameraSelector.DEFAULT_BACK_CAMERA
            if (!provider.hasCamera(selector)) {
                toast(ctx, ctx.getString(R.string.cam_err_no_camera))
                if (lensFront) lensFront = false
                return@LaunchedEffect
            }
            val preview = Preview.Builder().build()
            preview.setSurfaceProvider(previewView.surfaceProvider)
            val capture = ImageCapture.Builder()
                .setCaptureMode(
                    if (Prefs.quality(ctx) == 0) ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY
                    else ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY
                )
                .setFlashMode(flashMode)
                .build()
            val analysis: ImageAnalysis? = if (wantLive) {
                val a = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                a.setAnalyzer(analysisExecutor) { image ->
                    try {
                        val p = liveCfg.preset
                        if (p == null) {
                            if (liveBitmap != null) liveBitmap = null
                        } else {
                            val now = SystemClock.elapsedRealtime()
                            if (now - liveCfg.lastFrameAt >= 60L) {
                                liveCfg.lastFrameAt = now
                                var bmp = rgbaToBitmap(image)
                                val rot = image.imageInfo.rotationDegrees
                                val m = Matrix()
                                if (rot != 0) m.postRotate(rot.toFloat())
                                if (liveCfg.front) m.postScale(-1f, 1f)
                                if (!m.isIdentity) {
                                    bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                                }
                                liveBitmap = FilterEngine.apply(bmp, p, liveCfg.intensity)
                            }
                        }
                    } catch (e: Exception) {
                        // skip this frame
                    } finally {
                        image.close()
                    }
                }
                a
            } else {
                null
            }
            provider.unbindAll()
            val cam = if (analysis != null) {
                try {
                    val bound = provider.bindToLifecycle(lifecycleOwner, selector, preview, capture, analysis)
                    liveAvailable = true
                    bound
                } catch (e: Exception) {
                    // This phone cannot run preview + capture + analysis together: no live filter, filter after capture.
                    liveAvailable = false
                    provider.unbindAll()
                    provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
                }
            } else {
                provider.bindToLifecycle(lifecycleOwner, selector, preview, capture)
            }
            if (!wantLive) liveBitmap = null
            boundLens[0] = lensFront
            if (sameLens && keepZoom > 1.01f) cam.cameraControl.setZoomRatio(keepZoom)
            camera = cam
            imageCapture = capture
            singleLens = CameraDiagnostics.hasSingleExposedLens(ctx, lensFront)
            exposureIdx = 0
            startError = null
        } catch (e: Exception) {
            startError = ctx.getString(R.string.cam_err_start)
        }
    }

    // Filter thumbnails are built from one real preview frame (view-sized bitmap, scaled down).
    LaunchedEffect(camera) {
        if (camera == null) return@LaunchedEffect
        delay(1000)
        val frame = previewView.bitmap ?: return@LaunchedEffect
        filterThumbs = withContext(Dispatchers.Default) {
            val small = ImageUtils.scaleDown(frame, 120)
            val map = HashMap<String, Bitmap>()
            map["orig"] = small
            for (p in FilterEngine.presets) map[p.id] = FilterEngine.apply(small, p, 1f)
            map
        }
    }

    // Level indicator for the guide overlay: uses the accelerometer (phone held upright).
    DisposableEffect(assistMode != 0) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
        val sensor = sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent) {
                val x = event.values[0]
                val y = event.values[1]
                levelValid = y > 4f
                if (levelValid) {
                    val target = Math.toDegrees(Math.atan2((-x).toDouble(), y.toDouble())).toFloat()
                    rollDeg += (target - rollDeg) * 0.25f
                }
            }

            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (assistMode != 0 && sm != null && sensor != null) {
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_UI)
        }
        onDispose { sm?.unregisterListener(listener) }
    }

    // Follow the zoom state that CameraX actually reports (source of truth for the readout).
    DisposableEffect(camera) {
        val cam = camera
        val observer = Observer<ZoomState> { zs ->
            zoomRatio = zs.zoomRatio
            minZoom = zs.minZoomRatio
            maxZoom = zs.maxZoomRatio
        }
        cam?.cameraInfo?.zoomState?.observe(lifecycleOwner, observer)
        onDispose { cam?.cameraInfo?.zoomState?.removeObserver(observer) }
    }

    // Release the camera when leaving this screen (e.g. while editing a photo).
    DisposableEffect(Unit) {
        onDispose {
            try {
                providerHolder[0]?.unbindAll()
            } catch (e: Exception) {
                // ignore
            }
            analysisExecutor.shutdown()
        }
    }

    fun takePhoto() {
        val cap = imageCapture ?: return
        if (busy) return
        busy = true
        val file = File(ctx.cacheDir, "capture_" + System.currentTimeMillis() + ".jpg")
        val meta = ImageCapture.Metadata()
        meta.isReversedHorizontal = lensFront
        val options = ImageCapture.OutputFileOptions.Builder(file).setMetadata(meta).build()
        cap.takePicture(
            options,
            ContextCompat.getMainExecutor(ctx),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                    busy = false
                    onCaptured(file, livePresetId, liveIntensity)
                }

                override fun onError(exception: ImageCaptureException) {
                    busy = false
                    file.delete()
                    toast(ctx, ctx.getString(R.string.cam_err_capture))
                }
            }
        )
    }

    fun onShutter() {
        if (busy || countdown > 0) return
        if (timerSec == 0) {
            takePhoto()
        } else {
            scope.launch {
                for (i in timerSec downTo 1) {
                    countdown = i
                    delay(1000)
                }
                countdown = 0
                takePhoto()
            }
        }
    }

    val hasFlash = camera?.cameraInfo?.hasFlashUnit() == true
    val exposureState = camera?.cameraInfo?.exposureState

    Column(Modifier.fillMaxSize()) {
        // Top bar
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, contentDescription = stringResource(R.string.cd_settings), tint = MiraColors.Text)
            }
            Text(
                "Mira Camera",
                modifier = Modifier.weight(1f),
                fontSize = 15.sp,
                fontWeight = FontWeight.Light,
                letterSpacing = 1.sp
            )
            Pill(stringResource(R.string.cam_guide), onClick = onOpenGuide)
            Spacer(Modifier.width(6.dp))
            Pill(stringResource(R.string.cam_edit_photo), onClick = onPick)
        }

        // Viewfinder
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp), contentAlignment = Alignment.Center) {
            Box(
                Modifier
                    .aspectRatio(3f / 4f)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Color.Black)
            ) {
                AndroidView(factory = { previewView }, modifier = Modifier.fillMaxSize())

                val live = liveBitmap
                if (live != null) {
                    Image(
                        bitmap = remember(live) { live.asImageBitmap() },
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                if (gridMode != 0 || assistMode != 0) {
                    Canvas(Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val golden = gridMode == 2 && assistMode == 0
                        val a = if (golden) 0.382f else 1f / 3f
                        val b = if (golden) 0.618f else 2f / 3f
                        val line = Color(0x99FFFFFF)
                        drawLine(line, Offset(w * a, 0f), Offset(w * a, h), strokeWidth = 1.5f)
                        drawLine(line, Offset(w * b, 0f), Offset(w * b, h), strokeWidth = 1.5f)
                        drawLine(line, Offset(0f, h * a), Offset(w, h * a), strokeWidth = 1.5f)
                        drawLine(line, Offset(0f, h * b), Offset(w, h * b), strokeWidth = 1.5f)
                        val accent = Color(0xFFE6C58B)
                        if (assistMode == 1) {
                            drawLine(accent, Offset(0f, h * a), Offset(w, h * a), strokeWidth = 4f)
                        } else if (assistMode == 2) {
                            drawLine(accent, Offset(0f, h * a), Offset(w, h * a), strokeWidth = 4f)
                            drawLine(accent, Offset(0f, h * b), Offset(w, h * b), strokeWidth = 4f)
                        }
                        if (assistMode != 0 && levelValid) {
                            val level = kotlin.math.abs(rollDeg) < 1.5f
                            drawLine(Color(0x99FFFFFF), Offset(w * 0.38f, h / 2f), Offset(w * 0.62f, h / 2f), strokeWidth = 2f)
                            rotate(-rollDeg, Offset(w / 2f, h / 2f)) {
                                drawLine(
                                    if (level) Color(0xFF7FD99A) else Color(0xFFFFB86B),
                                    Offset(w * 0.3f, h / 2f),
                                    Offset(w * 0.7f, h / 2f),
                                    strokeWidth = 4f
                                )
                            }
                        }
                    }
                }

                // Pinch to zoom + tap to focus
                Box(
                    Modifier
                        .fillMaxSize()
                        .pointerInput(camera) {
                            detectTransformGestures { _, _, zoomChange, _ ->
                                val cam = camera ?: return@detectTransformGestures
                                cam.cameraControl.setZoomRatio((zoomRatio * zoomChange).coerceIn(minZoom, maxZoom))
                            }
                        }
                        .pointerInput(camera) {
                            detectTapGestures { offset ->
                                val cam = camera ?: return@detectTapGestures
                                val point = previewView.meteringPointFactory.createPoint(offset.x, offset.y)
                                cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
                                focusPoint = offset
                            }
                        }
                )

                focusPoint?.let { fp ->
                    Box(
                        Modifier
                            .offset { IntOffset((fp.x - 36.dp.toPx()).roundToInt(), (fp.y - 36.dp.toPx()).roundToInt()) }
                            .size(72.dp)
                            .border(2.dp, MiraColors.Accent, CircleShape)
                    )
                }

                Column(
                    Modifier.align(Alignment.TopCenter).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (hasFlash) {
                        val flashLabel = when (flashMode) {
                            ImageCapture.FLASH_MODE_ON -> R.string.cam_flash_on
                            ImageCapture.FLASH_MODE_AUTO -> R.string.cam_flash_auto
                            else -> R.string.cam_flash_off
                        }
                        Pill(stringResource(flashLabel), onClick = {
                            flashMode = when (flashMode) {
                                ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                                ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                                else -> ImageCapture.FLASH_MODE_OFF
                            }
                            imageCapture?.flashMode = flashMode
                        })
                    }
                    Pill(
                        if (timerSec == 0) stringResource(R.string.cam_timer_off)
                        else stringResource(R.string.cam_timer_sec, timerSec),
                        onClick = { timerSec = when (timerSec) { 0 -> 3; 3 -> 10; else -> 0 } }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val gridLabel = when (gridMode) {
                        1 -> R.string.cam_grid_thirds
                        2 -> R.string.cam_grid_golden
                        else -> R.string.cam_grid_off
                    }
                    Pill(stringResource(gridLabel), onClick = {
                        gridMode = (gridMode + 1) % 3
                        Prefs.setGrid(ctx, gridMode)
                    })
                    val assistLabel = when (assistMode) {
                        1 -> R.string.assist_portrait
                        2 -> R.string.assist_landscape
                        else -> R.string.assist_off
                    }
                    Pill(stringResource(assistLabel), selected = assistMode != 0, onClick = {
                        assistMode = (assistMode + 1) % 3
                    })
                    val activeName = FilterEngine.presets.firstOrNull { it.id == livePresetId }?.name
                    Pill(
                        activeName?.take(12) ?: stringResource(R.string.cam_filters),
                        selected = livePresetId != null || showFilters,
                        onClick = { showFilters = !showFilters }
                    )
                }
                }

                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(bottom = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (assistMode != 0) {
                        Text(
                            stringResource(if (assistMode == 1) R.string.assist_portrait_tip else R.string.assist_landscape_tip),
                            fontSize = 12.sp,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .padding(horizontal = 14.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x99000000))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                    if (livePresetId != null && !liveAvailable) {
                        Text(
                            stringResource(R.string.cam_live_unavailable),
                            fontSize = 12.sp,
                            color = Color.White,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .padding(horizontal = 14.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0x99000000))
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                    if (showFilters) {
                        if (livePresetId != null) {
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0x66000000))
                                    .padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    stringResource(R.string.ed_intensity, (liveIntensity * 100).roundToInt()),
                                    color = Color.White,
                                    fontSize = 12.sp,
                                    modifier = Modifier.width(110.dp)
                                )
                                Slider(
                                    value = liveIntensity,
                                    onValueChange = { liveIntensity = it },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 10.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                FilterCard(
                                    stringResource(R.string.cam_filter_none),
                                    filterThumbs["orig"],
                                    livePresetId == null
                                ) { livePresetId = null }
                            }
                            items(FilterEngine.presets, key = { it.id }) { p ->
                                FilterCard(p.name, filterThumbs[p.id], livePresetId == p.id) { livePresetId = p.id }
                            }
                        }
                    }
                }

                if (countdown > 0) {
                    Text(
                        countdown.toString(),
                        modifier = Modifier.align(Alignment.Center),
                        fontSize = 96.sp,
                        fontWeight = FontWeight.Thin,
                        color = Color.White
                    )
                }

                startError?.let {
                    Text(
                        it,
                        modifier = Modifier.align(Alignment.Center).padding(24.dp),
                        color = MiraColors.Danger,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Zoom + exposure
        Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp)) {
            if (maxZoom > minZoom) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
                ) {
                    for (r in listOf(0.5f, 1f, 2f, 5f, 10f)) {
                        if (r >= minZoom - 0.001f && r <= maxZoom + 0.001f) {
                            val label = if (r < 1f) "0.5×" else r.toInt().toString() + "×"
                            Pill(
                                label,
                                selected = abs(zoomRatio - r) < 0.05f,
                                onClick = { camera?.cameraControl?.setZoomRatio(r.coerceIn(minZoom, maxZoom)) }
                            )
                        }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val num = String.format(Locale.US, "%.1f", zoomRatio)
                    Text(
                        if (singleLens && zoomRatio > minZoom + 0.05f) stringResource(R.string.cam_zoom_digital, num)
                        else stringResource(R.string.cam_zoom_value, num),
                        color = MiraColors.TextDim,
                        fontSize = 12.sp,
                        modifier = Modifier.width(96.dp)
                    )
                    Slider(
                        value = zoomRatio.coerceIn(minZoom, maxZoom),
                        onValueChange = {
                            zoomRatio = it
                            camera?.cameraControl?.setZoomRatio(it.coerceIn(minZoom, maxZoom))
                        },
                        valueRange = minZoom..maxZoom,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
            if (exposureState != null && exposureState.isExposureCompensationSupported) {
                val range = exposureState.exposureCompensationRange
                if (range.upper > range.lower) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(stringResource(R.string.cam_exposure), color = MiraColors.TextDim, fontSize = 12.sp, modifier = Modifier.width(96.dp))
                        Slider(
                            value = exposureIdx.toFloat(),
                            onValueChange = {
                                exposureIdx = it.roundToInt()
                                camera?.cameraControl?.setExposureCompensationIndex(exposureIdx)
                            },
                            valueRange = range.lower.toFloat()..range.upper.toFloat(),
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // Bottom controls
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(72.dp), contentAlignment = Alignment.CenterStart) {
                val f = latest
                Box(
                    Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(1.dp, MiraColors.SurfaceHi, RoundedCornerShape(14.dp))
                        .clickable { onOpenAlbum() },
                    contentAlignment = Alignment.Center
                ) {
                    if (f != null) {
                        Thumb(f, Modifier.fillMaxSize())
                    } else {
                        Text(stringResource(R.string.cam_album), fontSize = 11.sp, color = MiraColors.TextDim)
                    }
                }
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                val active = !busy && countdown == 0
                Box(
                    Modifier
                        .size(78.dp)
                        .clip(CircleShape)
                        .border(3.dp, MiraColors.Text, CircleShape)
                        .clickable(enabled = active) { onShutter() },
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier
                            .size(62.dp)
                            .clip(CircleShape)
                            .background(if (active) MiraColors.Accent else MiraColors.TextDim)
                    )
                }
            }
            Box(Modifier.width(72.dp), contentAlignment = Alignment.CenterEnd) {
                Pill(stringResource(R.string.cam_flip), onClick = { lensFront = !lensFront })
            }
        }
    }
}

@Composable
private fun FilterCard(name: String, thumb: Bitmap?, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        Modifier.width(58.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(52.dp)
                .clip(shape)
                .background(MiraColors.SurfaceHi)
                .then(if (selected) Modifier.border(2.dp, MiraColors.Accent, shape) else Modifier)
        ) {
            if (thumb != null) {
                Image(
                    bitmap = remember(thumb) { thumb.asImageBitmap() },
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Text(
            name,
            fontSize = 10.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (selected) MiraColors.Accent else Color.White,
            modifier = Modifier.padding(top = 2.dp)
        )
    }
}
