package com.mira.camera

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File

object MiraColors {
    val Bg = Color(0xFF121316)
    val Surface = Color(0xFF1B1D21)
    val SurfaceHi = Color(0xFF272A30)
    val Accent = Color(0xFFE6C58B)
    val OnAccent = Color(0xFF1A1405)
    val Text = Color(0xFFECE9E2)
    val TextDim = Color(0xFF8E8C86)
    val Danger = Color(0xFFE5736A)
}

@Composable
fun MiraTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = MiraColors.Accent,
            onPrimary = MiraColors.OnAccent,
            background = MiraColors.Bg,
            onBackground = MiraColors.Text,
            surface = MiraColors.Surface,
            onSurface = MiraColors.Text,
            surfaceVariant = MiraColors.SurfaceHi,
            onSurfaceVariant = MiraColors.TextDim
        ),
        content = content
    )
}

fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

@Composable
fun Pill(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    selected: Boolean = false,
    enabled: Boolean = true
) {
    val bg = if (selected) MiraColors.Accent else MiraColors.SurfaceHi
    val fg = if (selected) MiraColors.OnAccent else MiraColors.Text
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = fg.copy(alpha = if (enabled) 1f else 0.4f),
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            maxLines = 1
        )
    }
}

@Composable
fun TopBar(title: String, onBack: () -> Unit, trailing: @Composable RowScope.() -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack) {
            Icon(Icons.Default.Close, contentDescription = stringResource(R.string.cd_close), tint = MiraColors.Text)
        }
        Text(
            title,
            fontSize = 18.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f).padding(start = 4.dp)
        )
        trailing()
    }
}

@Composable
fun MiraLogo(logoSize: Dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(logoSize)) {
        val c = center
        val r = size.minDimension / 2f
        drawCircle(
            brush = Brush.sweepGradient(
                listOf(MiraColors.Accent, Color(0xFFFFF1CF), Color(0xFFB98A45), MiraColors.Accent),
                center = c
            ),
            radius = r * 0.9f,
            center = c,
            style = Stroke(width = r * 0.12f)
        )
        drawCircle(color = Color(0xFF23201B), radius = r * 0.62f, center = c)
        drawCircle(color = MiraColors.Accent, radius = r * 0.62f, center = c, style = Stroke(width = r * 0.03f))
        drawCircle(color = Color(0xFF3A3228), radius = r * 0.3f, center = c)
        drawCircle(color = MiraColors.Accent, radius = r * 0.08f, center = Offset(c.x + r * 0.2f, c.y - r * 0.22f))
    }
}

@Composable
fun SplashScreen(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        a.animateTo(1f, tween(700))
        delay(600)
        onDone()
    }
    Column(
        Modifier.fillMaxSize().alpha(a.value),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        MiraLogo(110.dp)
        Spacer(Modifier.height(22.dp))
        Text("Mira Camera", fontSize = 28.sp, fontWeight = FontWeight.Light, letterSpacing = 2.sp)
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.splash_tagline), color = MiraColors.TextDim, fontSize = 14.sp)
    }
}

@Composable
fun Thumb(file: File, modifier: Modifier = Modifier) {
    var bmp by remember(file.path) { mutableStateOf(ThumbCache.get(file)) }
    var failed by remember(file.path) { mutableStateOf(false) }
    LaunchedEffect(file.path) {
        if (bmp == null) {
            val b = withContext(Dispatchers.IO) { ImageUtils.thumbnail(file, 360) }
            if (b == null) {
                failed = true
            } else {
                ThumbCache.put(file, b)
                bmp = b
            }
        }
    }
    Box(modifier.background(MiraColors.SurfaceHi), contentAlignment = Alignment.Center) {
        val image = bmp
        if (image != null) {
            Image(
                bitmap = remember(image) { image.asImageBitmap() },
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else if (failed) {
            Text(stringResource(R.string.album_missing), color = MiraColors.TextDim, fontSize = 11.sp)
        }
    }
}
