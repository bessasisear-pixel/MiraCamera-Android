package com.mira.camera

import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun EditorScreen(
    uri: Uri,
    fromCamera: Boolean,
    startTab: Int,
    onClose: () -> Unit,
    onSaved: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var source by remember { mutableStateOf<Bitmap?>(null) }
    var loadFailed by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf(EditState(intensity = Prefs.defaultIntensity(ctx))) }
    var rendered by remember { mutableStateOf<Bitmap?>(null) }
    var showOriginal by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(startTab) }
    var saving by remember { mutableStateOf(false) }
    var thumbs by remember { mutableStateOf<Map<String, Bitmap>>(emptyMap()) }
    val undoStack = remember { mutableStateListOf<EditState>() }
    val redoStack = remember { mutableStateListOf<EditState>() }
    var dragBase by remember { mutableStateOf<EditState?>(null) }

    fun applyDiscrete(new: EditState) {
        undoStack.add(edit)
        redoStack.clear()
        edit = new
    }

    fun applyLive(new: EditState) {
        if (dragBase == null) dragBase = edit
        edit = new
    }

    fun endLive() {
        val base = dragBase
        if (base != null && base != edit) {
            undoStack.add(base)
            redoStack.clear()
        }
        dragBase = null
    }

    fun undo() {
        if (undoStack.isEmpty()) return
        redoStack.add(edit)
        edit = undoStack.removeAt(undoStack.size - 1)
    }

    fun redo() {
        if (redoStack.isEmpty()) return
        undoStack.add(edit)
        edit = redoStack.removeAt(redoStack.size - 1)
    }

    BackHandler(enabled = !saving) { onClose() }
    BackHandler(enabled = saving) { }

    // Load a preview-sized copy of the photo.
    LaunchedEffect(uri) {
        val b = withContext(Dispatchers.IO) { ImageUtils.load(ctx, uri, 1280) }
        if (b == null) loadFailed = true else source = b
    }

    // Small previews of each filter preset, built once from the loaded photo.
    LaunchedEffect(source) {
        val s = source ?: return@LaunchedEffect
        thumbs = withContext(Dispatchers.Default) {
            val small = ImageUtils.scaleDown(s, 160)
            val map = HashMap<String, Bitmap>()
            map["orig"] = small
            for (p in FilterEngine.presets) map[p.id] = FilterEngine.apply(small, p, 1f)
            map
        }
    }

    // Re-render the preview whenever an edit changes.
    LaunchedEffect(source, edit) {
        val s = source ?: return@LaunchedEffect
        rendered = withContext(Dispatchers.Default) { Pipeline.render(s, edit) }
    }

    fun save() {
        if (saving) return
        saving = true
        val state = edit
        scope.launch {
            val result: PhotoStore.SaveResult? = withContext(Dispatchers.Default) {
                try {
                    val full = ImageUtils.load(ctx, uri, Prefs.maxSide(ctx))
                    if (full == null) {
                        null
                    } else {
                        PhotoStore.save(ctx, Pipeline.render(full, state))
                    }
                } catch (e: OutOfMemoryError) {
                    null
                } catch (e: Exception) {
                    null
                }
            }
            saving = false
            if (result == null || result.error) {
                Toast.makeText(ctx, ctx.getString(R.string.ed_save_failed), Toast.LENGTH_LONG).show()
            } else {
                val msg = when {
                    !Prefs.saveToGallery(ctx) -> R.string.ed_saved
                    result.galleryOk -> R.string.ed_saved_gallery
                    else -> R.string.ed_save_gallery_failed
                }
                Toast.makeText(ctx, ctx.getString(msg), Toast.LENGTH_SHORT).show()
                onSaved()
            }
        }
    }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            // Top bar
            Row(
                Modifier.fillMaxWidth().height(56.dp).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (fromCamera) {
                    Pill(stringResource(R.string.action_retake), onClick = onClose)
                } else {
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = stringResource(R.string.cd_close), tint = MiraColors.Text)
                    }
                }
                Text(
                    stringResource(if (fromCamera) R.string.ed_title_review else R.string.ed_title_edit),
                    modifier = Modifier.weight(1f),
                    textAlign = TextAlign.Center,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Medium
                )
                Pill(
                    stringResource(R.string.action_save),
                    onClick = { save() },
                    selected = true,
                    enabled = rendered != null && !saving
                )
            }

            // Image
            Box(
                Modifier.weight(1f).fillMaxWidth().padding(horizontal = 8.dp),
                contentAlignment = Alignment.Center
            ) {
                val shown = if (showOriginal) source else rendered
                val img = remember(shown) { shown?.asImageBitmap() }
                if (img != null) {
                    Image(
                        bitmap = img,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize().clip(RoundedCornerShape(14.dp))
                    )
                } else if (loadFailed) {
                    Text(stringResource(R.string.ed_load_failed), color = MiraColors.Danger)
                } else {
                    CircularProgressIndicator(color = MiraColors.Accent)
                }

                if (showOriginal) {
                    Text(
                        stringResource(R.string.ed_original),
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0x99000000))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        fontSize = 12.sp
                    )
                }

                if (img != null) {
                    Pill(
                        stringResource(R.string.ed_undo),
                        onClick = { undo() },
                        enabled = undoStack.isNotEmpty(),
                        modifier = Modifier.align(Alignment.BottomStart).padding(start = 10.dp, bottom = 10.dp)
                    )
                    Pill(
                        stringResource(R.string.ed_redo),
                        onClick = { redo() },
                        enabled = redoStack.isNotEmpty(),
                        modifier = Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 10.dp)
                    )
                    Box(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp)
                            .clip(RoundedCornerShape(50))
                            .background(Color(0xB3000000))
                            .pointerInput(Unit) {
                                detectTapGestures(onPress = {
                                    showOriginal = true
                                    tryAwaitRelease()
                                    showOriginal = false
                                })
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(stringResource(R.string.ed_compare), fontSize = 12.sp)
                    }
                }
            }

            // Tool panel
            Column(
                Modifier
                    .fillMaxWidth()
                    .height(272.dp)
                    .background(MiraColors.Surface, RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
                    .padding(12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    val tabs = listOf(R.string.ed_tab_filters, R.string.ed_tab_adjust, R.string.ed_tab_ai)
                    tabs.forEachIndexed { i, res ->
                        Pill(stringResource(res), onClick = { tab = i }, selected = tab == i)
                    }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                        Pill(stringResource(R.string.action_reset), onClick = {
                            applyDiscrete(EditState(intensity = Prefs.defaultIntensity(ctx)))
                        })
                    }
                }
                Box(Modifier.padding(top = 12.dp).fillMaxSize()) {
                    when (tab) {
                        0 -> FiltersTab(
                            thumbs, edit,
                            onEdit = { applyDiscrete(it) },
                            onLive = { applyLive(it) },
                            onEnd = { endLive() }
                        )
                        1 -> AdjustTab(
                            edit,
                            onEdit = { applyDiscrete(it) },
                            onLive = { applyLive(it) },
                            onEnd = { endLive() }
                        )
                        else -> AiTab()
                    }
                }
            }
        }

        if (saving) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0x99000000))
                    .pointerInput(Unit) { detectTapGestures { } },
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = MiraColors.Accent)
                    Text(stringResource(R.string.ed_saving), modifier = Modifier.padding(top = 12.dp))
                }
            }
        }
    }
}

@Composable
private fun FiltersTab(
    thumbs: Map<String, Bitmap>,
    edit: EditState,
    onEdit: (EditState) -> Unit,
    onLive: (EditState) -> Unit,
    onEnd: () -> Unit
) {
    val presets = FilterEngine.presets
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            items(FilterStyle.values().toList()) { st ->
                Pill(
                    stringResource(st.label),
                    selected = edit.preset?.style == st,
                    onClick = {
                        val idx = presets.indexOfFirst { it.style == st }
                        scope.launch { listState.animateScrollToItem(idx + 1) }
                    }
                )
            }
        }
        LazyRow(state = listState, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                PresetCard(
                    name = stringResource(R.string.ed_original),
                    thumb = thumbs["orig"],
                    selected = edit.preset == null,
                    onClick = { onEdit(edit.copy(preset = null)) }
                )
            }
            items(presets, key = { it.id }) { p ->
                PresetCard(
                    name = p.name,
                    thumb = thumbs[p.id],
                    selected = edit.preset?.id == p.id,
                    onClick = { onEdit(edit.copy(preset = p)) }
                )
            }
        }
        if (edit.preset != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.ed_intensity, (edit.intensity * 100).roundToInt()),
                    fontSize = 12.sp,
                    color = MiraColors.TextDim,
                    modifier = Modifier.width(112.dp)
                )
                Slider(
                    value = edit.intensity,
                    onValueChange = { onLive(edit.copy(intensity = it)) },
                    onValueChangeFinished = onEnd,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
private fun PresetCard(name: String, thumb: Bitmap?, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Column(
        Modifier.width(72.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier
                .size(64.dp)
                .clip(shape)
                .background(MiraColors.SurfaceHi)
                .then(if (selected) Modifier.border(2.dp, MiraColors.Accent, shape) else Modifier)
        ) {
            if (thumb != null) {
                Image(
                    bitmap = remember(thumb) { thumb.asImageBitmap() },
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
        Text(
            name,
            fontSize = 11.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            color = if (selected) MiraColors.Accent else MiraColors.TextDim,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun AdjustSlider(
    label: String,
    value: Float,
    range: ClosedFloatingPointRange<Float>,
    onLive: (Float) -> Unit,
    onEnd: () -> Unit
) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, fontSize = 12.sp, color = MiraColors.TextDim, modifier = Modifier.width(96.dp))
        Slider(
            value = value,
            onValueChange = onLive,
            onValueChangeFinished = onEnd,
            valueRange = range,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
private fun AdjustTab(
    edit: EditState,
    onEdit: (EditState) -> Unit,
    onLive: (EditState) -> Unit,
    onEnd: () -> Unit
) {
    Column(
        Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(R.string.ed_auto), fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Text(stringResource(R.string.ed_auto_desc), fontSize = 12.sp, color = MiraColors.TextDim)
            }
            Switch(checked = edit.enhance, onCheckedChange = { onEdit(edit.copy(enhance = it)) })
        }
        AdjustSlider(stringResource(R.string.ed_brightness), edit.brightness, -1f..1f,
            { onLive(edit.copy(brightness = it)) }, onEnd)
        AdjustSlider(stringResource(R.string.ed_contrast), edit.contrast, 0.5f..1.5f,
            { onLive(edit.copy(contrast = it)) }, onEnd)
        AdjustSlider(stringResource(R.string.ed_saturation), edit.saturation, 0f..2f,
            { onLive(edit.copy(saturation = it)) }, onEnd)
        AdjustSlider(stringResource(R.string.ed_temperature), edit.temperature, -1f..1f,
            { onLive(edit.copy(temperature = it)) }, onEnd)
        AdjustSlider(stringResource(R.string.ed_sharpness), edit.sharpness, 0f..1f,
            { onLive(edit.copy(sharpness = it)) }, onEnd)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(stringResource(R.string.ed_rotate), onClick = { onEdit(edit.copy(rotation = (edit.rotation + 1) % 4)) })
            Pill(stringResource(R.string.ed_flip_h), selected = edit.flipH, onClick = { onEdit(edit.copy(flipH = !edit.flipH)) })
            Pill(stringResource(R.string.ed_flip_v), selected = edit.flipV, onClick = { onEdit(edit.copy(flipV = !edit.flipV)) })
        }
        Text(stringResource(R.string.ed_crop), fontSize = 12.sp, color = MiraColors.TextDim)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            CropAspect.values().forEach { c ->
                Pill(
                    if (c == CropAspect.ORIGINAL) stringResource(R.string.ed_original) else c.label,
                    selected = edit.crop == c,
                    onClick = { onEdit(edit.copy(crop = c)) }
                )
            }
        }
    }
}

@Composable
private fun AiTab() {
    Column(
        Modifier.verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(stringResource(R.string.ai_intro), fontSize = 12.sp, color = MiraColors.TextDim)
        listOf(
            R.string.ai_style,
            R.string.ai_bg,
            R.string.ai_object,
            R.string.ai_portrait,
            R.string.ai_prompt
        ).forEach { res ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MiraColors.SurfaceHi)
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(stringResource(res), modifier = Modifier.weight(1f), fontSize = 14.sp)
                Text(stringResource(R.string.ai_status), color = MiraColors.Accent, fontSize = 12.sp)
            }
        }
    }
}
